public class Game
{
    String description;

    public Game()
    {

    }
    public Game(String d)
    {
        description = d;
    }

    public void setDescription(String s)
    {
        description = s;
    }

    public String getDescription()
    {
        return description;
    }

}
